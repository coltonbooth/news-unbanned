from django.apps import AppConfig


class NewsbackendConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'newsbackend'
